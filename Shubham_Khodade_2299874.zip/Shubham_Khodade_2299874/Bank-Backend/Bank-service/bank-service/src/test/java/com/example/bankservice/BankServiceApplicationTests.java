package com.example.bankservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
