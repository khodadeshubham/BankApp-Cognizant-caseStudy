package com.example.userservice.util;

public class ValueGenerator {

}
